

package maquina.teste;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class MaquinaTeste {

	

	@Test
	public void CalculaPreco() throws Exception {

			
			
		PrecoCalculado vpc = new PrecoCalculado();
		
		
		
		assertEquals(0, vpc.precoCalculado(""), 0.01);
		assertEquals(100, vpc.precoCalculado("w"), 0.01);
		assertEquals(160, vpc.precoCalculado("W;X"), 0.01);
		assertEquals(230, vpc.precoCalculado("Y;Z;X;W"), 0.01);
		
		
		
		
		assertEquals(200, vpc.precoCalculado("w;W"), 0.01);
		assertEquals(260, vpc.precoCalculado("w;w;W"), 0.01);
		assertEquals(360, vpc.precoCalculado("W;W;W;W"), 0.01);
		assertEquals(460, vpc.precoCalculado("W;W;W;W;w"), 0.01);
		assertEquals(560, vpc.precoCalculado("W;W;W;W;W;W"), 0.01);
		
		
		
		assertEquals(320, vpc.precoCalculado("W;W;W;X"), 0.01);
		assertEquals(350, vpc.precoCalculado("W;W;W;x;X"), 0.01);
		assertEquals(380, vpc.precoCalculado("W;W;W;X;X;Z"), 0.01);
		assertEquals(380, vpc.precoCalculado("Z;W;X;W;X;W"), 0.01);
		assertEquals(380, vpc.precoCalculado("Z;W;X;W;X;W"), 0.01);
		
	
		

		CalculaPreco calc = new CalculaPreco();
		
								 assertEquals(0, calc.precoTotal(), 0.01);
		calc.verificaPreco("W"); assertEquals(100, calc.precoTotal(), 0.01);
		calc.verificaPreco("X"); assertEquals(160, calc.precoTotal(), 0.01);
		calc.verificaPreco("W"); assertEquals(260, calc.precoTotal(), 0.01);
		calc.verificaPreco("W"); assertEquals(320, calc.precoTotal(), 0.01);
		calc.verificaPreco("X"); assertEquals(350, calc.precoTotal(), 0.01);
		
			
		
	}

}
