package maquina.teste;

public class CalculaPreco {
	
	double totalProdutos = 0;
	
	
	 double W = 100.00;
	 double X = 60.00;
	 double Y = 40.00;
	 double Z = 30.00;
	 double promoW = 260;
	 double promoX = 90;
	 
	 int countW=0;
	 int countX=0;
	 
	 boolean flagPromoW=true;
	 boolean flagPromoX=true;
	 
	public double verificaPreco(String produto1) {

		String produto = produto1;
		
		 
				 if(produto.equalsIgnoreCase("W")) {
					 countW++;
					 if(countW==3 && flagPromoW) {
						  //garante a aplica��o da promo��o (3 por 260) apenas 1x. Considerando que o terceiro
						  //produto ainda nao foi acrescentado ao valor totalProduto, faz a subtra��o apenas de w*2
							 totalProdutos=totalProdutos-(W*2);
							 totalProdutos=totalProdutos+promoW;
							 flagPromoW=false;
						
					 }else
						 //inclui valor produto ao valor totalproduto
						 totalProdutos=totalProdutos+W;
				 }
				 else if(produto.equalsIgnoreCase("X")) {
					 countX++;
					 if(countX==2 && flagPromoX) {
						 //garante a aplica��o da promo��o (2 por 90) apenas 1x. Considerando que o segundo
						  //produto ainda nao foi acrescentado ao valor totalProduto, faz a subtra��o apenas de x*1
							 totalProdutos=totalProdutos-(X*1);
							 totalProdutos=totalProdutos+promoX;
							 flagPromoW=false;
						
					 }else
						 //inclui valor produto ao valor totalproduto
						 totalProdutos=totalProdutos+X;
				 }
				 else if(produto.equalsIgnoreCase("Z")) {
					 //inclui valor produto ao valor totalproduto
					 totalProdutos=totalProdutos+Z;
					 
				 }
				 else if(produto.equalsIgnoreCase("Y")) {
					 //inclui valor produto ao valor totalproduto
					 totalProdutos=totalProdutos+Y;
					 
				 }

		 
		 
			 return totalProdutos;

}
	

	public double precoTotal() {
		
		return totalProdutos;
	}
}
