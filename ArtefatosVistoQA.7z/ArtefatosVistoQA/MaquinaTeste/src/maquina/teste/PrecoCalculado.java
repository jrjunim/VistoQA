package maquina.teste;

public class PrecoCalculado {

	
	public double precoCalculado(String produtos) {

		String produtos1 = produtos;
		 String[] produtosSeparados = produtos1.split(";");
		 double totalProdutos = 0;
		 
		 double W = 100.00;
		 double X = 60.00;
		 double Y = 40.00;
		 double Z = 30.00;
		 
		 int countW=0;
		 int countX=0;
		 
		 //NOTA1: verifica a quantidade de produtos X e W, que dever�o ser validados como pre�o promocional quando:
		 // |Produto           |Pre�o unit�rio | Promo��o  |
		 //	|W				   |100			   | 3 por 260 |
		 // |X				   |60			   | 2 por 90  |
		 
		 
		 for (int index = 0; index < produtosSeparados.length; index++) {
			 
			 if(produtosSeparados[index].equalsIgnoreCase("W"))
				 countW++;
			 else if(produtosSeparados[index].equalsIgnoreCase("X"))
				 countX++;
		 }


			 
		 
		 //NOTA2: Estabelece promo��o para produtos incluidos nas condi��es da NOTA1
		 //mant�m contador para quantidade de produtos acima da quantidade promocional 
		 if(countW>=3) {
			 totalProdutos=260;
			 countW=countW-3;
		 }
		 
		 if(countX>=2) {
			 totalProdutos=totalProdutos+90;
			 countX=countX-2;
		 }
		 
		 
		 //NOTA3: realiza o calculo valor / produtos
		 for (int index = 0; index < produtosSeparados.length; index++) {
			 
			 if(produtosSeparados[index].equalsIgnoreCase("W") && countW!=0) {
				 totalProdutos=totalProdutos + W;
				 countW--;
			 }
			 else if(produtosSeparados[index].equalsIgnoreCase("X") && countX!=0) {
				 totalProdutos=totalProdutos + X;
				 countX--;
			 }
			 else if(produtosSeparados[index].equalsIgnoreCase("Y"))
				 totalProdutos=totalProdutos + Y;
			 
			 else if(produtosSeparados[index].equalsIgnoreCase("Z"))
				 totalProdutos=totalProdutos + Z;
		 }
		 
		 
		 //NOTA4: retorna valor total produtos
		 return totalProdutos;
		


		
}
}

